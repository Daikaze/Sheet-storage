import {openManager} from "./manager.mjs";
import {MODULE_ID, mayManage, getStorage} from "./storage.mjs";

/** Find the placed Token when the sheet is reached via either actor sheet or token config. */
function tokenFromSheet(app) {
  const d = app.document ?? app.object;
  if (d?.documentName === "Token") return d;
  if (app.token?.documentName === "Token") return app.token;
  const actor = app.actor ?? (d?.documentName === "Actor" ? d : null);
  if (!actor) return null;
  if (actor.token?.documentName === "Token") return actor.token;
  const controlled = canvas?.tokens?.controlled ?? [];
  const selected = controlled.find(t => t.document?.actorId === actor.id || t.actor?.id === actor.id);
  if (selected) return selected.document;
  const matching = (canvas?.tokens?.placeables ?? []).filter(t => t.document?.actorId === actor.id);
  return matching.length === 1 ? matching[0].document : null;
}

function fromSheet(app) {
  const token = tokenFromSheet(app);
  if (!token) return ui.notifications.warn("Select a placed token that uses this actor, then open Form Storage.");
  openManager(token);
}

Hooks.once("init", () => {
  if (game.system.id !== "dnd5e") return;
  console.info("Token Form Storage | Starting v1.0.1 for Foundry v14 / dnd5e 6.0.6");
});

// Modern ApplicationV2-based D&D 5e actor sheets and Foundry token settings.
Hooks.on("getHeaderControlsApplicationV2", (app, controls) => {
  if (game.system.id !== "dnd5e") return;
  const d = app.document ?? app.object;
  const sheet = d?.documentName === "Actor" || d?.documentName === "Token" ||
    app.actor?.documentName === "Actor";
  if (!sheet || !Array.isArray(controls)) return;
  if (controls.some(c => c.action === "tokenFormStorage")) return;
  controls.unshift({
    action: "tokenFormStorage",
    icon: "fa-solid fa-layer-group",
    label: "Token Forms",
    visible: true,
    onClick: () => fromSheet(app)
  });
});

// Legacy sheets and third-party sheets still using ApplicationV1.
Hooks.on("getActorSheetHeaderButtons", (app, buttons) => {
  if (game.system.id !== "dnd5e") return;
  if (!buttons.some(b => b.class === "token-form-storage-open")) buttons.unshift({
    label: "Token Forms",
    class: "token-form-storage-open",
    icon: "fas fa-layer-group",
    onclick: () => fromSheet(app)
  });
});

// On right-clicked Token HUD, open form storage without opening the actor sheet.
Hooks.on("renderTokenHUD", (app, root) => {
  if (game.system.id !== "dnd5e") return;
  const token = app.object?.document ?? app.document ?? app.object;
  if (token?.documentName !== "Token" || !mayManage(token)) return;
  const html = root instanceof HTMLElement ? root : root?.[0];
  if (!html || html.querySelector(".tfs-hud-control")) return;
  const target = html.querySelector(".col.right, .right, .controls.right") ?? html;
  const button = document.createElement("button");
  button.type = "button";
  button.className = "tfs-hud-control control-icon";
  button.title = "Token Form Storage — switch complete forms";
  button.setAttribute("aria-label", "Token Form Storage");
  button.innerHTML = `<i class="fa-solid fa-layer-group"></i>`;
  button.addEventListener("click", event => {
    event.preventDefault();
    event.stopPropagation();
    openManager(token);
  });
  target.append(button);
});

// Public, narrowly scoped macro helper for users who want a one-click hotkey.
Hooks.once("ready", () => {
  if (game.system.id !== "dnd5e") return;
  game.modules.get(MODULE_ID).api = Object.freeze({
    openForSelectedToken() {
      const token = canvas?.tokens?.controlled?.[0]?.document;
      if (!token) return ui.notifications.warn("Select a token first.");
      return openManager(token);
    },
    getForms(tokenDocument) {
      if (!tokenDocument?.actor) return [];
      const storage = getStorage(tokenDocument);
      return storage.forms.map(f => ({id: f.id, name: f.name, actorId: f.actorId, active: f.id === storage.activeId}));
    }
  });
});
