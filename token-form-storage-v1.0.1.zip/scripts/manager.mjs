import {
  getStorage, mayManage, actorAllowed, switchForm, saveCurrent, addActorForm, duplicateSnapshot,
  createActorClone, renameForm, removeForm, registerCurrentActor
} from "./storage.mjs";

const Dialog = foundry.applications.api.DialogV2;
const HbsApp = foundry.applications.api.HandlebarsApplicationMixin(foundry.applications.api.ApplicationV2);

async function askName(title, proposed = "") {
  const text = foundry.utils.escapeHTML(proposed);
  const data = await Dialog.input({
    window: {title},
    content: `<div class="form-group"><label>Form name</label><input type="text" name="name" maxlength="80" value="${text}" autofocus required></div>`,
    ok: {label: "Save"},
    rejectClose: false
  });
  return data ? String(data.name ?? "").trim() : null;
}

export class FormStorageManager extends HbsApp {
  static DEFAULT_OPTIONS = {
    id: "token-form-storage-{id}",
    classes: ["token-form-storage-app"],
    tag: "div",
    window: {title: "Token Form Storage", icon: "fa-solid fa-layer-group", resizable: true},
    position: {width: 590, height: 525},
    actions: {
      switch: FormStorageManager.doSwitch,
      save: FormStorageManager.doSave,
      edit: FormStorageManager.doEdit,
      add: FormStorageManager.doAdd,
      duplicate: FormStorageManager.doDuplicate,
      clone: FormStorageManager.doClone,
      rename: FormStorageManager.doRename,
      remove: FormStorageManager.doRemove,
      recover: FormStorageManager.doRecover
    }
  };

  static PARTS = {main: {template: "modules/token-form-storage/templates/manager.hbs"}};

  constructor(token, options = {}) {
    super(options);
    this.token = token;
    this._busy = false;
  }

  get title() { return `Forms · ${this.token?.name ?? "Token"}`; }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const token = this.token;
    const storage = getStorage(token);
    const mismatched = storage.forms.find(f => f.id === storage.activeId)?.actorId !== token.actorId;
    const forms = storage.forms.map(form => {
      const actor = game.actors.get(form.actorId);
      return {
        id: form.id,
        name: form.name,
        actorName: actor?.name || "Missing Actor",
        image: form.snapshot?.texture?.src || actor?.img || "icons/svg/mystery-man.svg",
        active: storage.activeId === form.id,
        missing: !actor,
        allowed: actorAllowed(actor),
        items: actor?.items?.size ?? 0
      };
    });
    const actors = game.actors.contents
      .filter(actor => actorAllowed(actor) && actor.type !== "group")
      .sort((a, b) => a.name.localeCompare(b.name))
      .map(actor => ({id: actor.id, name: actor.name, image: actor.img}));
    return {
      ...context,
      tokenName: token.name,
      currentActor: token.actor?.name || "Unknown",
      forms,
      actors,
      hasActors: actors.length > 0,
      canManage: mayManage(token),
      linked: token.actorLink,
      canClone: game.user.isGM,
      mismatched,
      tokenId: token.id,
      hasSeveral: forms.length > 1
    };
  }

  async run(fn) {
    if (this._busy) return;
    this._busy = true;
    try { await fn(); }
    catch (err) {
      console.error("Token Form Storage | Action failed", err);
      ui.notifications.error(`Token Form Storage: ${err.message}`);
    } finally {
      this._busy = false;
      await this.render();
    }
  }

  static async doSwitch(event, button) {
    return this.run(async () => {
      await switchForm(this.token, button.dataset.formId);
      ui.notifications.info("Token form switched.");
    });
  }
  static async doEdit(event, button) {
    const storage = getStorage(this.token);
    const form = storage.forms.find(f => f.id === button.dataset.formId);
    if (!form) return;
    const actor = form.id === storage.activeId ? this.token.actor : game.actors.get(form.actorId);
    if (!actorAllowed(actor)) return ui.notifications.warn("You cannot open this Actor's sheet.");
    actor.sheet.render({force: true});
  }
  static async doSave() {
    return this.run(async () => {
      await saveCurrent(this.token);
      ui.notifications.info("Current form saved.");
    });
  }
  static async doAdd() {
    return this.run(async () => {
      const selected = this.element.querySelector("[name='alternateActor']")?.value;
      if (!selected) return ui.notifications.warn("Choose an Actor from the dropdown first.");
      const actor = game.actors.get(selected);
      const name = await askName("Add Actor as Form", actor?.name || "");
      if (name === null) return;
      await addActorForm(this.token, selected, name);
      ui.notifications.info("Form added to this token.");
    });
  }
  static async doDuplicate() {
    return this.run(async () => {
      const name = await askName("Save Snapshot as Another Form", `${this.token.actor.name} (Copy)`);
      if (name === null) return;
      await duplicateSnapshot(this.token, name);
      ui.notifications.info("Separate token form saved.");
    });
  }
  static async doClone() {
    return this.run(async () => {
      const name = await askName("Duplicate Actor as a New Form", `${this.token.actor.name} (Alternate)`);
      if (name === null) return;
      const actor = await createActorClone(this.token, name);
      ui.notifications.info(`New Actor '${actor.name}' added as a form.`);
    });
  }
  static async doRename(event, button) {
    return this.run(async () => {
      const selected = getStorage(this.token).forms.find(f => f.id === button.dataset.formId);
      if (!selected) return;
      const name = await askName("Rename Form", selected.name);
      if (name === null) return;
      await renameForm(this.token, selected.id, name);
    });
  }
  static async doRemove(event, button) {
    return this.run(async () => {
      const form = getStorage(this.token).forms.find(f => f.id === button.dataset.formId);
      if (!form) return;
      const okay = await Dialog.confirm({
        window: {title: "Remove Stored Form"},
        content: `<p>Remove <strong>${foundry.utils.escapeHTML(form.name)}</strong> from this token's storage?</p><p>The world Actor will not be deleted.</p>`,
        rejectClose: false
      });
      if (okay) await removeForm(this.token, form.id);
    });
  }
  static async doRecover() {
    return this.run(async () => {
      await registerCurrentActor(this.token);
      ui.notifications.info("Current Actor registered as an active form.");
    });
  }
}

const windows = new Map();
export function openManager(token) {
  if (!token?.actor) return ui.notifications.warn("Select a token on the canvas first.");
  if (!mayManage(token)) return ui.notifications.warn("You do not have permission to manage this token.");
  const key = token.uuid;
  let app = windows.get(key);
  if (!app) {
    app = new FormStorageManager(token);
    windows.set(key, app);
    app.addEventListener("close", () => windows.delete(key), {once: true});
  }
  app.render({force: true});
  return app;
}
